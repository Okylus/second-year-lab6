CREATE TABLE IF NOT EXISTS STUDENTS (
    id int NOT NULL AUTO_INCREMENT,
    name varchar(15),
    surname varchar(25),
    faculty varchar(20),
    age int,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS DISCIPLINES (
    id int NOT NULL AUTO_INCREMENT,
    name varchar(50),
    department varchar(30),
    hours int,
    PRIMARY KEY (id)
);
