package ru.kuchumov.MySpringBoot2Dbase.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.kuchumov.MySpringBoot2Dbase.entity.Student;
import ru.kuchumov.MySpringBoot2Dbase.model.ApiResponse;
import ru.kuchumov.MySpringBoot2Dbase.service.StudentService;
import java.util.List;

@RestController
@RequestMapping("/api")
public class MyController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/students")
    public ResponseEntity<ApiResponse<List<Student>>> allStudents() {
        List<Student> students = studentService.getAllStudents();
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Список студентов успешно получен", students));
    }

    @GetMapping("/students/{id}")
    public ResponseEntity<ApiResponse<Student>> getStudent(@PathVariable("id") int id) {
        Student student = studentService.getStudent(id);
        if (student == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ApiResponse<>(false, "Студент с id=" + id + " не найден", null));
        }
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Студент успешно найден", student));
    }

    @PostMapping("/students")
    public ResponseEntity<ApiResponse<Student>> saveStudent(@RequestBody Student student) {
        Student saved = studentService.saveStudent(student);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                new ApiResponse<>(true, "Студент успешно добавлен", saved));
    }

    @PutMapping("/students")
    public ResponseEntity<ApiResponse<Student>> updateStudent(@RequestBody Student student) {
        Student existing = studentService.getStudent(student.getId());
        if (existing == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ApiResponse<>(false, "Ошибка обновления: студент не найден", null));
        }
        Student updated = studentService.saveStudent(student);
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Данные студента успешно обновлены", updated));
    }

    @DeleteMapping("/students/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteStudent(@PathVariable("id") int id) {
        boolean deleted = studentService.deleteStudent(id);
        if (!deleted) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ApiResponse<>(false, "Ошибка удаления: студент с id=" + id + " не найден", null));
        }
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Студент с id=" + id + " успешно удален", null));
    }
}
