package ru.kuchumov.MySpringBoot2Dbase.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.kuchumov.MySpringBoot2Dbase.entity.Discipline;
import ru.kuchumov.MySpringBoot2Dbase.model.ApiResponse;
import ru.kuchumov.MySpringBoot2Dbase.service.DisciplineService;
import java.util.List;

@RestController
@RequestMapping("/api")
public class DisciplineController {

    @Autowired
    private DisciplineService disciplineService;

    @GetMapping("/disciplines")
    public ResponseEntity<ApiResponse<List<Discipline>>> allDisciplines() {
        List<Discipline> list = disciplineService.getAllDisciplines();
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Список учебных дисциплин успешно получен", list));
    }

    @GetMapping("/disciplines/{id}")
    public ResponseEntity<ApiResponse<Discipline>> getDiscipline(@PathVariable("id") int id) {
        Discipline d = disciplineService.getDiscipline(id);
        if (d == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ApiResponse<>(false, "Дисциплина с id=" + id + " не найдена", null));
        }
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Дисциплина успешно найдена", d));
    }

    @PostMapping("/disciplines")
    public ResponseEntity<ApiResponse<Discipline>> saveDiscipline(@RequestBody Discipline d) {
        Discipline saved = disciplineService.saveDiscipline(d);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                new ApiResponse<>(true, "Дисциплина успешно добавлена", saved));
    }

    @PutMapping("/disciplines")
    public ResponseEntity<ApiResponse<Discipline>> updateDiscipline(@RequestBody Discipline d) {
        if (disciplineService.getDiscipline(d.getId()) == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ApiResponse<>(false, "Ошибка обновления: дисциплина не найдена", null));
        }
        Discipline updated = disciplineService.saveDiscipline(d);
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Дисциплина успешно обновлена", updated));
    }

    @DeleteMapping("/disciplines/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteDiscipline(@PathVariable("id") int id) {
        if (!disciplineService.deleteDiscipline(id)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                    new ApiResponse<>(false, "Ошибка удаления: дисциплина не найдена", null));
        }
        return ResponseEntity.ok(new ApiResponse<>(
                true, "Дисциплина с id=" + id + " успешно удалена", null));
    }
}
